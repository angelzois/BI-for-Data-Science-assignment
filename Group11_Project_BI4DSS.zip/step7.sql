USE oltp_schema;
CREATE VIEW SalesSummaryByProductCategoryFiltered1 AS
SELECT
    SUBSTRING_INDEX(ProductID, '-', -1) AS ProductCategory,
    COUNT(InvoiceID) AS TotalSales,
    SUM(Quantity) AS TotalQuantity,
    SUM(Total) AS TotalRevenue,
    AVG(GrossIncome) AS AverageGrossIncome
FROM factsales
WHERE Total > 460
GROUP BY ProductCategory
ORDER BY TotalRevenue DESC;



